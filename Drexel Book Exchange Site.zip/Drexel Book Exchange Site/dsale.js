        /* NDW Added in form validation using JavaScript */
            
        function validate() {
      
         if( document.myForm.name.value == "" ) {
            alert( "Please provide your name!" );
            document.myForm.Name.focus() ;
            return false;
         }
         if( document.myForm.email.value == "" ) {
            alert( "Please provide your Email!" );
            document.myForm.email.focus() ;
            return false;
         }
         if( document.myForm.zip.value == "" || isNaN( document.myForm.zip.value ) ||
            document.myForm.zip.value.length != 5 ) {
            
            alert( "Please provide a zip in the format #####." );
            document.myForm.zip.focus() ;
            return false;
         }
         if( document.myForm.state.value == "-1" ) {
            alert( "Please provide your State!" );
            return false;
         }
             
         if( document.myForm.address.value == "" ) {
            alert( "Please provide your Street Address!" );
            document.myForm.address.focus() ;
            return false;
         }
             
         if( document.myForm.phone.value == "" ) {
            alert( "Please provide your Phone Number!" );
            document.myForm.phone.focus() ;
            return false;
         }
             
         if( document.myForm.dept.value == "" ) {
            alert( "Please provide the Academic Department!" );
            document.myForm.dept.focus() ;
            return false;
         }
         
         if( document.myForm.section.value == "" ) {
            alert( "Please provide the Class Section!" );
            document.myForm.section.focus() ;
            return false;
         }  
            
         if(( document.myForm.ebook.checked == false ) && ( document.myForm.print.checked == false )) { alert( "Please select EBook or Print!"); return false;
                                                                                    
         }
/* NDW The radio button validation was an absolute bear to figure out for some reason, so I'm glad to have that working now! */
            
           alert("The form was submitted");
            
            
            
         return( true );  
            
           
        
      }
Hi <?php echo htmlspecialchars($_POST['name']); ?>.
